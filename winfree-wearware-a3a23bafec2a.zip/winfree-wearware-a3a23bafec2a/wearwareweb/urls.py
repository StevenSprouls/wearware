"""wearwareweb URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import include, url
from django.contrib import admin

from wearware.views import *

urlpatterns = [
    url(r'^$', home, name='index'),

    # subject endpoints
    url(r'^subject/(?P<subject_id>[0-9]+)/fitbit/associate/$', fitbit_init_auth, name='fitbit-init-auth'),

    # study endpoints
    url(r'^study/new/$', study_new, name='study-add'),
    url(r'^study/(?P<study_id>[0-9]+)/edit/$', study_edit, name='study-edit'),
    url(r'^study/(?P<study_id>[0-9]+)/delete/$', study_delete, name='study-delete'),

    url(r'^study/(?P<study_id>[0-9]+)/$', study_summary, name='study-summary'),
    url(r'^study/(?P<study_id>[0-9]+)/summary/json/$', study_summary_json, name='study-summary-json'),
    url(r'^study/(?P<study_id>[0-9]+)/sync_records/$', study_sync_history, name='study-sync-records'),
    url(r'^study/(?P<study_id>[0-9]+)/csv_export/$', export_study_data_as_zip, name='study-csv-export'),

    url(r'^study/(?P<study_id>[0-9]+)/subjects/$', subject_manage, name='study-subject-manage'),
    url(r'^study/(?P<study_id>[0-9]+)/subjects/enroll/$', subject_enroll, name='study-subject-enroll'),
    url(r'^study/(?P<study_id>[0-9]+)/subjects/(?P<subject_id>[0-9]+)/delete/$', subject_delete,
        name='study-subject-delete'),

    url(r'^study/(?P<study_id>[0-9]+)'
        r'/subjects/(?P<subject_id>[0-9]+)'
        r'/events/$',
        event_manage,
        name='study-subject-event-manage'),

    url(r'^study/(?P<study_id>[0-9]+)'
        r'/subjects/(?P<subject_id>[0-9]+)'
        r'/events/register/$',
        event_create,
        name='study-subject-event-create'),

    url(r'^study/(?P<study_id>[0-9]+)'
        r'/subjects/(?P<subject_id>[0-9]+)'
        r'/events/(?P<event_id>[0-9]+)/edit/$',
        event_edit,
        name='study-subject-event-edit'),

    url(r'^study/(?P<study_id>[0-9]+)'
        r'/subjects/(?P<subject_id>[0-9]+)'
        r'/events/(?P<event_id>[0-9]+)/delete/$',
        event_delete,
        name='study-subject-event-delete'),

    # helper account endpoints
    url(r'^helpers/$', helper_summary, name='helper-summary'),
    url(r'^helpers/new/$', helper_create, name='helper-create'),
    url(r'^helpers/(?P<username>[A-Za-z0-9_@+\.\-]+)/delete/$', helper_delete, name='helper-delete'),

    # helper permissions endpoints
    url(r'^helpers/(?P<username>[A-Za-z0-9_@+\.\-]+)/revoke_permission/'
        r'(?P<study_id>[0-9]+)/(?P<permission>[A-Za-z_]+)/$',
        helper_revoke_permission, name='helper-delete-permission'),

    url(r'^helpers/(?P<username>[A-Za-z0-9_@+\.\-]+)/grant_permission/'
        r'(?P<permission>[A-Za-z_]+)/$',
        helper_grant_permission, name='helper-add-permission'),

    # API endpoints
    url(r'^api/fitbit/callback/$', fitbit_initial_oauth_callback),
    url(r'^api/fitbit/notification$', fitbit_receive_notification),

    # django and registration apps
    url(r'^accounts/', include('registration.backends.default.urls')),
    url(r'^admin/', include(admin.site.urls)),
]
