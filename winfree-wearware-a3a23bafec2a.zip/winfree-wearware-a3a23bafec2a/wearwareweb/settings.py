from __future__ import absolute_import
# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
from datetime import timedelta

import db_dev
import db_prd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.8/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '3bnf720zk4%3v$55@m@cd(w885=db5k+14ib68nkimlwg4lc2t'
SITE_ID = 1

FITBIT_CLIENT_ID = '229VTC'
FITBIT_CLIENT_SECRET = '789657eaf4ed81a6b8a2a7af831fbdc6'
FITBIT_API_THRESHOLD = 20
FITBIT_SUBSCRIBER_VERIFICATION_CODE = '0e858a00cd034d0c80470b36102c16ec01cbe619410b0e5527c26a15d200c6b9'

if os.environ.get('DEPLOY_SITE') == 'production':
    DEBUG = False
    DATABASES = db_prd.DATABASES
    BROKER_URL = db_prd.CELERY_BROKER_URL
    LOG_LEVEL = 'INFO'
else:
    # FIXME this needs to be configured more dynamically, will currently break
    DEBUG = True
    DATABASES = db_dev.DATABASES
    BROKER_URL = db_dev.CELERY_BROKER_URL
    LOG_LEVEL = 'DEBUG'

CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'

CELERYBEAT_SCHEDULE = {
    'fitbit-refresh-tokens': {
        'task': 'wearware.tasks.fitbit_refresh_tokens',
        'schedule': timedelta(minutes=10),
        'args': (),
    },
    'activate-new-studies-daily': {
        'task': 'wearware.tasks.activate_current_studies',
        'schedule': timedelta(days=1),
        'args': (),
    },
    'deactivate-expired-studies-daily': {
        'task': 'wearware.tasks.deactivate_expired_studies',
        'schedule': timedelta(days=1),
        'args': (),
    }
}

# Honor the 'X-Forwarded-Proto' header for request.is_secure()
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

# Allow all host headers
ALLOWED_HOSTS = ['*']

# FIXME this prevents deployment outside of NAU
EMAIL_HOST = 'mailgate.nau.edu'
EMAIL_PORT = 25
EMAIL_USE_TLS = True
SERVER_EMAIL = 'kyle.winfree@nau.edu'
DEFAULT_FROM_EMAIL = SERVER_EMAIL

ADMINS = (('Kyle Winfree', 'kyle.winfree@nau.edu'),)
MANAGERS = ADMINS

# Application definition

INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.sites',
    'django.contrib.staticfiles',
    'django_extensions',
    'registration',
    'bootstrap3',
    'bootstrap3_datepicker',
    'django_bootstrap_breadcrumbs',
    'guardian',
    'wearware',
)

AUTHENTICATION_BACKENDS = (
    'django.contrib.auth.backends.ModelBackend',  # default
    'guardian.backends.ObjectPermissionBackend',
)
ANONYMOUS_USER_ID = -1

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sites.middleware.CurrentSiteMiddleware',
    'wearwareweb.middleware.VerboseRequestLoggingMiddleware',
)

ROOT_URLCONF = 'wearwareweb.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'wearwareweb', 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'wearwareweb.wsgi.application'

# Internationalization
# https://docs.djangoproject.com/en/1.8/topics/i18n/

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'America/Phoenix'
USE_I18N = True
USE_L10N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.8/howto/static-files/

STATIC_URL = '/static/'
STATIC_ROOT = 'staticfiles'
STATICFILES_DIRS = (
    os.path.join(BASE_DIR, 'static/'),
)

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s [%(asctime)s] %(name)s %(message)s'
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'verbose'
        },
        'file': {
            'level': 'INFO',
            'class': 'logging.FileHandler',
            'filename': '/var/log/wearware.log',
            'formatter': 'verbose',
        },
        'mail_admins': {
            'level': 'ERROR',
            'filters': [],
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'WARN',
            'propagate': True,
        },
        'django': {
            'handlers': ['console', 'file'],
            'propagate': True,
            'level': 'INFO',
        },
        'wearware': {
            'handlers': ['console', 'file'],
            'propagate': True,
            'level': LOG_LEVEL,
        },
    }
}

PASSWORD_HASHERS = (
    'django.contrib.auth.hashers.BCryptSHA256PasswordHasher',
    'django.contrib.auth.hashers.BCryptPasswordHasher',
    'django.contrib.auth.hashers.PBKDF2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher',
    'django.contrib.auth.hashers.SHA1PasswordHasher',
    'django.contrib.auth.hashers.MD5PasswordHasher',
    'django.contrib.auth.hashers.CryptPasswordHasher',
)

LOGIN_REDIRECT_URL = '/'

ACCOUNT_ACTIVATION_DAYS = 14
REGISTRATION_OPEN = False
INCLUDE_REGISTER_URL = False
