import logging

import django.utils.timezone as timezone
from ipware import ip


class VerboseRequestLoggingMiddleware(object):
    """Middleware to log requests more verbosely."""
    def __init__(self):
        self.log = logging.getLogger('wearware')

    start_time = None

    def process_request(self, request):
        self.start_time = timezone.now()

    def process_response(self, request, response):
        try:
            remote_addr = ip.get_real_ip(request)
            user_email = getattr(request.user, 'username', '-')

            req_time = timezone.now() - self.start_time
            content_len = len(response.content)

            self.log.info('IP %s, USER %s, METHOD %s, PATH %s, STATUS %s, RESPONSE-LENGTH %s, (%02d ms)',
                          remote_addr, user_email, request.method, request.get_full_path(), response.status_code,
                          content_len,
                          req_time.total_seconds() * 1000)

        except Exception as e:
            self.log.error("LoggingMiddleware Error: %s", e)

        return response
