var startDate = null;
var end_date = null;
var usageChart;
var activityChart;

Highcharts.setOptions({
    global: {
        useUTC: false
    }
});

var subjectCheckTemplate = Handlebars.compile($('#subject-checkbox-template').html());

console.log('Loading server-rendered JS for study "{{ study.identifier }}" (id {{ study.pk }})');

var data_url = "{% url 'study-summary-json' study_id=study.pk %}?";
console.log('Using "' + data_url + '" as base URL for all async requests.');

$(document).ready(function () {
    $('#async_content').hide();
    var lastWeek = new Date();
    lastWeek.setDate(lastWeek.getDate() - 7);

    var today = new Date();
    today = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    var datepickerOptions = {
        autoclose: true,
        todayHighlight: true,
        endDate: '0d'
    };

    var startPicker = $('#start_date_picker');
    var endPicker = $('#end_date_picker');

    startPicker.datepicker(datepickerOptions);
    endPicker.datepicker(datepickerOptions);

    startPicker.on('changeDate', function (e) {
        startDate = e.date;
        $('#graph_refresh_button').removeClass('disabled');
    });

    endPicker.on('changeDate', function (e) {
        end_date = e.date;
        $('#graph_refresh_button').removeClass('disabled');
    });

    startPicker.datepicker('update', lastWeek);
    endPicker.datepicker('update', today);

    startPicker.trigger('changeDate');
    endPicker.trigger('changeDate');

    startDate = lastWeek;
    end_date = today;

    $('#graph_refresh_button').click(function () {
        refreshGraph(startDate, end_date);
    });
});

function refreshGraph(startDate, endDate) {
    var params = {start: formatDate(startDate), end: formatDate(endDate)};
    var buildButton = $('#graph_refresh_button');
    var buildButtonHtml = buildButton.html();

    var subjectButton = $('#show_hide_subjects_button');
    var subjectButtonHtml = subjectButton.html();

    $.ajax({
        dataType: "json",
        url: data_url + jQuery.param(params),
        beforeSend: function () {
            $('#async_content').hide();
            $('#wear_level_chart').html('');
            $('#activity_level_chart').html('');
            $('#subject_buttons').html('');

            buildButton.addClass('disabled');
            buildButton.html('Loading...');
        },
        success: function (data) {
            $('#async_content').show();

            var usageTraces = [];
            var activityTraces = [];

            var subjectButtons = $('#subject_buttons');

            var subjects = [];

            for (var subject in data) {
                if (data.hasOwnProperty(subject)) {
                    var mutatedSubject = {'id': subject};

                    var numMinutes = 0;
                    var numRecords = 0;

                    var usageTrace = {name: subject, data: []};
                    data[subject]['usage'].forEach(function (d) {
                        var millis = Date.parse(d.hour_ending_at);
                        usageTrace.data.push([millis, d.number_of_records]);

                        numRecords += d.number_of_records;
                        numMinutes += 60;
                    });
                    mutatedSubject.usage = usageTrace;
                    //usageTraces.push(usageTrace);

                    var activityTrace = {name: subject, data: []};
                    data[subject]['activity'].forEach(function (d) {
                        var millis = Date.parse(d.time);
                        activityTrace.data.push([millis, d.level])
                    });

                    //sort trace for highcharts
                    mutatedSubject.activity = activityTrace;
                    //activityTraces.push(trace);

                    var percentage = Math.floor((numRecords / numMinutes) * 100);

                    if (numMinutes == 0) {
                        percentage = 0;
                    }
                    mutatedSubject.percentage = percentage;

                    subjects.push(mutatedSubject);
                }
            }

            subjects.sort(function (a, b) {
                return a.percentage - b.percentage;
            });

            for (index = 0; index < subjects.length; index++) {
                var currentSubject = subjects[index];

                activityTraces.push(currentSubject.activity);
                usageTraces.push(currentSubject.usage);

                var rowContext = {
                    subjectID: currentSubject.id,
                    percentageUsed: currentSubject.percentage,
                    index: index
                };

                var checkHTML = subjectCheckTemplate(rowContext);
                subjectButtons.append(checkHTML);

                // register checkbox handler to show/hide series index in graphs
                $('#subject_check_' + index).change(function (event) {
                    var check_id = parseInt(event.target.id.split('_')[2]);
                    if (this.checked) {
                        usageChart.series[check_id].show();
                        activityChart.series[check_id].show();
                    } else {
                        usageChart.series[check_id].hide();
                        activityChart.series[check_id].hide();
                    }
                });
            }

            usageChart = new Highcharts.StockChart({
                chart: {
                    renderTo: 'wear_level_chart'
                },
                title: {
                    text: 'Fitbit Usage Levels'
                },
                xAxis: {
                    title: {
                        text: 'Date/Time'
                    },
                    type: 'datetime'
                },
                yAxis: {
                    title: {
                        text: 'Minutes per hour collected'
                    },
                    min: 0,
                    max: 60
                },
                scrollbar: {
                    enabled: false
                },
                series: usageTraces
            });

            activityChart = new Highcharts.StockChart({
                chart: {
                    renderTo: 'activity_level_chart'
                },
                title: {
                    text: 'Fitbit Activity Levels'
                },
                xAxis: {
                    title: {
                        text: 'Date/Time'
                    },
                    type: 'datetime'
                },
                yAxis: {
                    title: {
                        text: 'Fitbit-defined activity level'
                    },
                    min: 0,
                    max: 3
                },
                scrollbar: {
                    enabled: false
                },
                series: activityTraces
            });

        },
        error: function (xhr, status, error) {
            console.log('Unable to fetch wear level data: ' + status + '  ' + error);
            // TODO display error message on page

            $('#async_content').hide();
        },
        complete: function () {
            $('#wear_level_chart').show();
            $('#activity_level_chart').show();

            buildButton.html(buildButtonHtml);

            subjectButton.removeClass('disabled');
            subjectButton.html(subjectButtonHtml);
        }
    });
}

function formatDate(date) {
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    return year.toString() + month.toString() + day.toString();
}
