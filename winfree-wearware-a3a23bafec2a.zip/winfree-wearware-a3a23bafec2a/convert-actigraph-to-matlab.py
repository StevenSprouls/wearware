
# coding: utf-8

# Using the format documentation here:
# 
# https://github.com/actigraph/GT3X-File-Format

# In[1]:

input_path = 'Kyle.gt3x'
output_path = 'kyle_out_adam_dont_delete_this.mat'
SCALING_FACTOR = 256.0


# In[2]:

import datetime as dt
import scipy.io as sio
import struct
import zipfile as zf


# In[3]:

# we'll just read everything into memory for speed
# verify that files exist, and then parse it later
with zf.ZipFile(input_path) as zipped:
    info_path = 'info.txt'
    with zipped.open(info_path) as info_file:
        print(info_path, 'opened successfully')
        info_bytes = zipped.read(info_path)
    
    log_path = 'log.bin'
    with zipped.open(log_path) as log_file:
        print(log_path, 'opened successfully')
        log_bytes = bytearray(zipped.read(log_path))


# In[4]:

# parse out the sample rate and start time from info.txt
for l in info_bytes.decode().split('\r\n'):
    if 'Sample Rate: ' in l:
        sample_rate = int(l.split(': ')[1].strip())
        
    if 'Start Date: ' in l:
        mu_secs = int(l.split(': ')[1].strip()) / 10
        start_date = dt.datetime(1, 1, 1) + dt.timedelta(microseconds=mu_secs)

print('sample rate', sample_rate)
print('start date', start_date)


# In[5]:

rec_types = {
    0: 'ACTIVITY',
    2: 'BATTERY',
    3: 'EVENT',
    4: 'HEART_RATE_BPM',
    5: 'LUX',
    6: 'METADATA',
    7: 'TAG',
    9: 'EPOCH',
    11: 'HEART_RATE_ANT',
    12: 'EPOCH2',
    13: 'CAPSENSE',
    14: 'HEART_RATE_BLE',
    15: 'EPOCH3',
    16: 'EPOCH4',
    21: 'PARAMETERS',
    24: 'SENSOR_SCHEMA',
    25: 'SENSOR_DATA',
    26: 'ACTIVITY2',
    255: 'INTERNAL',
}


# In[6]:

recs = {v: [] for k, v in rec_types.items()}
recs['samplerate'] = sample_rate

i = 0
while i < len(log_bytes):
    if log_bytes[i] != 30:
        print('invalid record start:', log_bytes[i])
        break
    
    tp_offset = i + 1
    ts_offset = i + 2
    sz_offset = i + 6
    pl_offset = i + 8
    
    type_byte = log_bytes[tp_offset]
    # figure out what type record we have
    rec_type = rec_types.get(type_byte, 'INTERNAL')
    
    ts_bytes = log_bytes[ts_offset:ts_offset+4]
    timestamp = int.from_bytes(ts_bytes, byteorder='little')
    
    size_bytes = log_bytes[sz_offset:sz_offset+2]
    size = int.from_bytes(size_bytes, byteorder='little')
    
    payload = bytearray()
    
    for j in range(pl_offset, pl_offset + size):
        payload.append(log_bytes[j])    
    
    checksum_byte = log_bytes[pl_offset + size]
    
    i = pl_offset + size + 1
    
    # we don't care about internal records
    if rec_type == 'INTERNAL':
        continue
    
    # since the checksum is good, we'll add it to our records
    recs[rec_type].append({
            'type': rec_type,
            'timestamp': timestamp,
            'size': size,
            'payload': payload,
            'checksum': checksum_byte,
    })


# In[7]:

def int_from_12bit_twos_comp(bit_str):
    val = int(bit_str, 2)
    return -(val & 0b100000000000) | (val & 0b011111111111)

for r in recs['ACTIVITY']:
    bits = ''
    pl = r['payload']
    
    r['X'] = []
    r['Y'] = []
    r['Z'] = []
    
    # convert the byte array to raw bits -- ick
    for b in pl:
        new_bits = bin(b)[2:]
        bits += (8 - len(new_bits)) * '0' #python strips left-padding zeroes by default
        bits += new_bits
    
    # now we have all the bits, so lets go through on YXZ set at a time
    for i in range(0, len(bits), 36):
        y_bits = bits[i:i+12]
        x_bits = bits[i+12:i+24]
        z_bits = bits[i+24:i+36]
        
        if len(x_bits) < 12 or len(y_bits) < 12 or len(z_bits) < 12:
            break
        
        x = int_from_12bit_twos_comp(x_bits)
        y = int_from_12bit_twos_comp(y_bits)
        z = int_from_12bit_twos_comp(z_bits)
        
        x_scaled = x / SCALING_FACTOR
        y_scaled = y / SCALING_FACTOR
        z_scaled = z / SCALING_FACTOR
        
        x_rnd = int(x_scaled * 1000) / 1000.0
        y_rnd = int(y_scaled * 1000) / 1000.0
        z_rnd = int(z_scaled * 1000) / 1000.0
        
        r['X'].append(x_rnd)
        r['Y'].append(y_rnd)
        r['Z'].append(z_rnd)


# In[8]:

sio.savemat(output_path, recs)


# In[ ]:



