# wearware

Deploying wearware is a little more complex than just a simple web service, because it relies on an active RabbitMQ instance to work correctly.

The basic requirements:

* nginx to forward connections
* PostgreSQL to store data (9.3 currently)
* RabbitMQ to store background jobs (fetches from Fitbit API at the moment)

Then three processes must be launched for the application:

* wearware (the web application which serves data)
* wearware-celery (the workers which fetch data in the background)
* wearware-celerybeat (the timer job which ensures authentication credentials are up to date)

## Deployment:

```
sudo service wearware-celerybeat stop
sudo service wearware-celery stop
sudo service wearware stop

cd /opt/wearware
git pull origin master

source /opt/wwenv/bin/activate
./manage.py collectstatic

# copy any deployment artifacts where they may need to go
# BE CAREFUL!!!
sudo cp deployment_artifacts/* /

# restart nginx and postgres if configurations changed
sudo service nginx restart
sudo service postgresql restart

# start up the changed services
sudo service wearware start
sudo service wearware-celery start
sudo service wearware-celerybeat start
```

## Setup

Currently deployed to Ubuntu 14.04. Upgrading will require writing systemd service unit files for the services, and then deploying those instead of the upstart scripts.

.bash_history from server setup (amended, truncated, etc.), on Ubuntu Server 14.04:

```
# remaining assumes that network interfaces are up, etc

# disable root login
sudo nano /etc/ssh/sshd_config
sudo service ssh restart

# get latest apt entries
sudo apt-get update && sudo apt-get upgrade

# configure firewall
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw allow from 134.114.117.0/24 to any port 5432
sudo ufw default deny incoming
sudo ufw show added
sudo ufw enable
sudo ufw status

# some intrusion detection
sudo apt-get install fail2ban
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
# tweak the defaults a bit
sudo nano /etc/fail2ban/jail.local
sudo service fail2ban restart
sudo iptables -L

# install AMPQ and other dependencies
# add rabbitmq apt repo to sources
sudo nano /etc/apt/sources.list
wget https://www.rabbitmq.com/rabbitmq-signing-key-public.asc
sudo apt-key add rabbitmq-signing-key-public.asc
rm rabbitmq-signing-key-public.asc
sudo apt-get update
sudo apt-get install \
    rabbitmq-server python3-pip python3-dev \
    nginx ntp postgresql postgresql-contrib \
    libpq-dev libffi6 libffi-dev

# clean up
sudo apt-get autoremove

# copy all config files to appropriate locations HERE
# the deployment artifacts

# restart to grab new config, prep the database, create a superuser, and verify they can login
sudo service postgresql restart
sudo -i -u postgres
createdb wearware
createuser -P -s wearware
psql -d wearware -U wearware -W
exit

sudo mkdir /opt/wearware
# now copy the repo contents to /opt/wearware

# create the virtual environment
sudo pip3 install virtualenv
cd /opt
sudo virtualenv wwenv

# take all the ownerships
sudo chown -R adam:adam /opt/wearware/
sudo chown -R adam:adam /opt/wwenv/

# prep the application itself now
source /opt/wwenv/bin/activate
pip install -r requirements.txt

cd /opt/wearware
./manage.py migrate

# this step is optional unless you need to migrate the existing database
# to get this kind of dump, run ./manage.py dumpdata wearware auth.User auth.Group
./manage.py loaddata wearwaredump_partial_20151221.json
./manage.py collectstatic

# tell nginx where to expect the service
sudo ln -s /etc/nginx/sites-available/wearware /etc/nginx/sites-enabled/
sudo service nginx configtest
sudo service nginx restart

# get the log ready to write to -- this is an awful hack
sudo touch /var/log/wearware.log
sudo chown adam:adam /var/log/wearware.log

sudo service wearware start
sudo service wearware-celerybeat start
sudo service wearware-celery start
```
