from django.test import TestCase

# Create your tests here.

# FIXME write some tests.
