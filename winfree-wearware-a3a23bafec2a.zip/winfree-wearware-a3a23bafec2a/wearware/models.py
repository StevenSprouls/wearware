import uuid

from django.db import models


class Study(models.Model):
    """A study. 'Owns' subjects."""
    identifier = models.CharField(max_length=150, unique=True)
    start_date = models.DateField()
    end_date = models.DateField()
    comment = models.CharField(max_length=2000, default='', blank=True)

    def __str__(self):
        return self.identifier

    class Meta:
        permissions = (
            ('view_study_data', 'View and export study data.'),
            ('add_subject_to_study', 'Create a new subject and add to study.'),
        )


class Subject(models.Model):
    """A subject in a study. 'Owns' an optional fitbit account."""
    identifier = models.CharField(max_length=100)
    study = models.ForeignKey(Study, db_index=True)
    email = models.EmailField()

    sex = models.CharField(max_length=1,
                           choices=(('M', 'Male'), ('F', 'Female')))

    gender = models.CharField(max_length=1,
                              choices=(('M', 'Male'), ('F', 'Female'), ('O', 'Other')))

    # should always be rotated whenever an attempt is made at pairing
    pairing_token = models.UUIDField(default=uuid.uuid4, editable=True)

    study_start_date = models.DateField(verbose_name='earliest date for data sync')

    comments = models.CharField(max_length=500, default='', blank=True)

    def __str__(self):
        return self.identifier


class FitbitAccount(models.Model):
    """Actual fitbit account. Owned by a subject."""
    identifier = models.CharField(max_length=10, db_index=True)
    subject = models.ForeignKey(Subject, db_index=True)
    is_active = models.BooleanField(default=True)
    timezone = models.CharField(max_length=50)
    last_updated = models.DateTimeField()
    token_type = models.CharField(max_length=20, blank=True)
    refresh_token = models.CharField(max_length=100, blank=True)
    access_token = models.CharField(max_length=300, blank=True)

    def __str__(self):
        return self.subject.identifier + '\'s fitbit'


class ManualEvent(models.Model):
    """A manually recorded event for a subject."""
    subject = models.ForeignKey(Subject)
    study = models.ForeignKey(Study)
    timestamp = models.DateTimeField(auto_now=True)
    event = models.CharField(max_length=1000)

    def __str__(self):
        return self.subject.identifier + ' @ ' + str(self.timestamp) + ': ' + self.event


class FitbitMinuteRecord(models.Model):
    """A single minute-resolution record for a given fitbit account. Owns >= 0 HR records."""
    device = models.ForeignKey(FitbitAccount, db_index=True)
    timestamp = models.DateTimeField(db_index=True)
    steps = models.IntegerField(db_index=True, null=True, blank=True)
    calories = models.FloatField(null=True, blank=True)
    mets = models.FloatField(null=True, blank=True)
    activity_level = models.IntegerField(null=True, blank=True)
    distance = models.FloatField(null=True, blank=True)

    def __str__(self):
        return self.device.subject.identifier + ' fitbit @ ' + str(self.timestamp)


class FitbitHeartRecord(models.Model):
    """A single heart-rate record from Fitbit. Owned by a minute-level record."""
    minute_record = models.ForeignKey(FitbitMinuteRecord, db_index=True)
    second = models.IntegerField()
    bpm = models.IntegerField()


class SyncRecord(models.Model):
    """A metadata record for a given sync interval. Useful for debugging."""
    device = models.ForeignKey(FitbitAccount)
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    sync_type = models.CharField(max_length=100, db_index=True)
    successful = models.BooleanField(default=True)
    message = models.CharField(max_length=10000, default='')
