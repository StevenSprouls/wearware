from bootstrap3_datepicker.widgets import DatePickerInput
from django import forms
from django.contrib.auth.models import User
from .models import Study, Subject, ManualEvent


class StudyCreateForm(forms.ModelForm):
    """
    Form to create a study.

    Significantly more complex than the default form generation, but not bad.
    """
    skip_date_validation = forms.BooleanField(widget=forms.HiddenInput, required=False)

    class Meta:
        model = Study
        fields = ['identifier', 'start_date', 'end_date', 'comment', 'skip_date_validation']
        widgets = {
            'start_date': DatePickerInput(format='%m/%d/%Y'),
            'end_date': DatePickerInput(format='%m/%d/%Y'),
            'comment': forms.Textarea(),
        }

    def clean(self):
        """Warns when creating a study which overlaps with another (single lab per deploy)."""
        cleaned_data = super(StudyCreateForm, self).clean()

        if not self.data['skip_date_validation']:

            overlaps_start_date = Study.objects.filter(start_date__lte=cleaned_data['start_date'],
                                                       end_date__gte=cleaned_data['start_date'])

            overlaps_end_date = Study.objects.filter(start_date__lte=cleaned_data['end_date'],
                                                     end_date__gte=cleaned_data['end_date'])

            overlaps_contained = Study.objects.filter(start_date__gte=cleaned_data['start_date'],
                                                      start_date__lte=cleaned_data['end_date'],
                                                      end_date__gte=cleaned_data['start_date'],
                                                      end_date__lte=cleaned_data['end_date'])

            overlaps = []
            overlaps.extend(s.identifier for s in overlaps_start_date)
            overlaps.extend(s.identifier for s in overlaps_end_date)
            overlaps.extend(s.identifier for s in overlaps_contained)

            if len(overlaps) > 0:
                self.data = self.data.copy()
                self.data['skip_date_validation'] = True
                raise forms.ValidationError('This study overlaps with dates of existing studies: {} '
                                            'Click Confirm to acknowledge that these studies overlap.'.format(overlaps))

        return cleaned_data


class StudyEditForm(forms.ModelForm):
    class Meta:
        model = Study
        fields = ['identifier', 'comment']
        widgets = {
            'comment': forms.Textarea(),
        }


class SubjectEnrollForm(forms.ModelForm):
    class Meta:
        model = Subject
        fields = ['identifier', 'email', 'sex', 'gender', 'comments', 'study', 'study_start_date']
        widgets = {
            'study': forms.HiddenInput(),
            'study_start_date': DatePickerInput(format='%m/%d/%Y'),
        }


class ManualEventForm(forms.ModelForm):
    class Meta:
        model = ManualEvent
        fields = ['subject', 'study', 'event']
        widgets = {
            'subject': forms.HiddenInput(),
            'study': forms.HiddenInput(),
        }


class HelperCreateForm(forms.ModelForm):
    password = forms.CharField(widget=forms.HiddenInput)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']

    def __init__(self, *args, **kwargs):
        super(HelperCreateForm, self).__init__(*args, **kwargs)

        self.fields['first_name'].required = True
        self.fields['last_name'].required = True
        self.fields['email'].required = True

    def save(self, commit=True):
        helper = super(HelperCreateForm, self).save(commit=False)
        helper.set_password(self.cleaned_data['password'])

        if commit:
            helper.save()
        return helper


class HelperPermissionGrantForm(forms.Form):
    study_to_grant = forms.ModelChoiceField(queryset=None, empty_label=None)

    def __init__(self, *args, studies=None, **kwargs):
        super(HelperPermissionGrantForm, self).__init__(*args, **kwargs)
        if studies:
            self.fields['study_to_grant'].queryset = studies
