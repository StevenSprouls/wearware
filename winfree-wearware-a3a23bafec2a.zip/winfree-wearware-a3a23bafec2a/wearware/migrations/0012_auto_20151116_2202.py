# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models
from django.utils.timezone import utc
import datetime


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0011_syncrecord_sync_type'),
    ]

    operations = [
        migrations.AddField(
            model_name='syncrecord',
            name='end_time',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 16, 22, 2, 11, 798316, tzinfo=utc)),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='syncrecord',
            name='start_time',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 16, 22, 2, 15, 914265, tzinfo=utc)),
            preserve_default=False,
        ),
    ]
