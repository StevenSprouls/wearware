# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0015_auto_20151124_1429'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='study',
            options={'permissions': (('view_study_data', 'View and export study data.'),
                                     ('add_subject_to_study', 'Create a new subject and add to study.'))},
        ),
    ]
