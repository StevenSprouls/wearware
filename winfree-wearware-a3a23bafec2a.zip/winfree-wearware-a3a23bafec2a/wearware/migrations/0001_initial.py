# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Device',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, primary_key=True, verbose_name='ID')),
                ('device_type', models.CharField(max_length=25)),
                ('auth_json', models.CharField(max_length=1000)),
            ],
        ),
        migrations.CreateModel(
            name='ManualEvent',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, primary_key=True, verbose_name='ID')),
                ('timestamp', models.DateTimeField(auto_now=True)),
                ('event', models.CharField(max_length=1000)),
            ],
        ),
        migrations.CreateModel(
            name='MinuteRecord',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, primary_key=True, verbose_name='ID')),
                ('timestamp', models.DateTimeField()),
                ('data_json', models.CharField(max_length=10485760)),
                ('device', models.ForeignKey(to='wearware.Device')),
            ],
        ),
        migrations.CreateModel(
            name='Study',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, primary_key=True, verbose_name='ID')),
                ('identifier', models.CharField(max_length=150)),
                ('start_date', models.DateField()),
                ('end_date', models.DateField()),
                ('comment', models.CharField(max_length=500)),
            ],
        ),
        migrations.CreateModel(
            name='Subject',
            fields=[
                ('id', models.AutoField(auto_created=True, serialize=False, primary_key=True, verbose_name='ID')),
                ('identifier', models.CharField(max_length=100)),
                ('email', models.CharField(max_length=100)),
                ('sex', models.CharField(max_length=1, choices=[('M', 'Male'), ('F', 'Female')])),
                ('gender', models.CharField(max_length=1, choices=[('M', 'Male'), ('F', 'Female'), ('O', 'Other')])),
                ('comments', models.CharField(max_length=500)),
                ('study', models.ForeignKey(to='wearware.Study')),
            ],
        ),
        migrations.AddField(
            model_name='manualevent',
            name='study',
            field=models.ForeignKey(to='wearware.Study'),
        ),
        migrations.AddField(
            model_name='manualevent',
            name='subject',
            field=models.ForeignKey(to='wearware.Subject'),
        ),
        migrations.AddField(
            model_name='device',
            name='subject',
            field=models.ForeignKey(to='wearware.Subject'),
        ),
    ]
