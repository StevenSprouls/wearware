# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0023_remove_fitbitaccount_auth_json'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='fitbitaccount',
            name='device_type',
        ),
    ]
