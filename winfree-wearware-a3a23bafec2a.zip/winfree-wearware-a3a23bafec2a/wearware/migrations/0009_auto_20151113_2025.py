# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0008_auto_20151113_1806'),
    ]

    operations = [
        migrations.AlterField(
            model_name='device',
            name='identifier',
            field=models.CharField(db_index=True, max_length=10),
        ),
    ]
