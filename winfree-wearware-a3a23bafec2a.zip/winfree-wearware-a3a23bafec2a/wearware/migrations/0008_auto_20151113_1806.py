# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0007_auto_20151113_1802'),
    ]

    operations = [
        migrations.AlterField(
            model_name='device',
            name='identifier',
            field=models.CharField(unique=True, max_length=10, db_index=True),
        ),
        migrations.AlterField(
            model_name='minuterecord',
            name='timestamp',
            field=models.DateTimeField(db_index=True),
        ),
    ]
