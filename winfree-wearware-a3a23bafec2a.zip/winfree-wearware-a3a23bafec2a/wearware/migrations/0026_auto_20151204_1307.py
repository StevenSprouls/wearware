# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0025_auto_20151204_1258'),
    ]

    operations = [
        migrations.CreateModel(
            name='FitbitHeartRecord',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, auto_created=True, verbose_name='ID')),
                ('second', models.IntegerField()),
                ('bpm', models.IntegerField()),
            ],
        ),
        migrations.AddField(
            model_name='fitbitminuterecord',
            name='activity_level',
            field=models.IntegerField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='fitbitminuterecord',
            name='calories',
            field=models.FloatField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='fitbitminuterecord',
            name='distance',
            field=models.FloatField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='fitbitminuterecord',
            name='mets',
            field=models.FloatField(null=True, blank=True),
        ),
        migrations.AddField(
            model_name='fitbitminuterecord',
            name='steps',
            field=models.IntegerField(null=True, blank=True, db_index=True),
        ),
        migrations.AddField(
            model_name='fitbitheartrecord',
            name='minute_record',
            field=models.ForeignKey(to='wearware.FitbitMinuteRecord'),
        ),
    ]
