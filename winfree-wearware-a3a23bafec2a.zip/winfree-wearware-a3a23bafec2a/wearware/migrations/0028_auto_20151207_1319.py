# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0027_remove_fitbitminuterecord_data_json'),
    ]

    operations = [
        migrations.AlterField(
            model_name='subject',
            name='email',
            field=models.EmailField(max_length=254),
        ),
    ]
