# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0020_remove_device_metadata_json'),
    ]

    operations = [
        migrations.AddField(
            model_name='device',
            name='access_token',
            field=models.CharField(max_length=300, blank=True),
        ),
        migrations.AddField(
            model_name='device',
            name='refresh_token',
            field=models.CharField(max_length=100, blank=True),
        ),
        migrations.AddField(
            model_name='device',
            name='token_type',
            field=models.CharField(max_length=20, blank=True),
        ),
    ]
