# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0010_syncrecord'),
    ]

    operations = [
        migrations.AddField(
            model_name='syncrecord',
            name='sync_type',
            field=models.CharField(max_length=100, default='fitbit'),
            preserve_default=False,
        ),
    ]
