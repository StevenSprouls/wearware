# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0002_device_last_updated'),
    ]

    operations = [
        migrations.AddField(
            model_name='device',
            name='metadata_json',
            field=models.CharField(default='', max_length=500),
            preserve_default=False,
        ),
    ]
