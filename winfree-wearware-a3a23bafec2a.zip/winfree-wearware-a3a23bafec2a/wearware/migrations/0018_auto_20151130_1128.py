# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0017_auto_20151125_1008'),
    ]

    operations = [
        migrations.AlterField(
            model_name='study',
            name='comment',
            field=models.CharField(default='', blank=True, max_length=2000),
        ),
        migrations.AlterField(
            model_name='subject',
            name='comments',
            field=models.CharField(default='', blank=True, max_length=500),
        ),
    ]
