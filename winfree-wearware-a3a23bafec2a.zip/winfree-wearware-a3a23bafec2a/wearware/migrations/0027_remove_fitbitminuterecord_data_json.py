# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0026_auto_20151204_1307'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='fitbitminuterecord',
            name='data_json',
        ),
    ]
