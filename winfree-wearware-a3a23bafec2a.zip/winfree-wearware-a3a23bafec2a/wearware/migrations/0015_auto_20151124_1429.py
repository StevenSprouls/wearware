# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0014_auto_20151124_1427'),
    ]

    operations = [
        migrations.AlterField(
            model_name='syncrecord',
            name='timestamp',
            field=models.DateTimeField(db_index=True, auto_now_add=True),
        ),
    ]
