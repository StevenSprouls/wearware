# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0009_auto_20151113_2025'),
    ]

    operations = [
        migrations.CreateModel(
            name='SyncRecord',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, auto_created=True, verbose_name='ID')),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('successful', models.BooleanField(default=True)),
                ('message', models.CharField(default='', max_length=10000)),
                ('device', models.ForeignKey(to='wearware.Device')),
            ],
        ),
    ]
