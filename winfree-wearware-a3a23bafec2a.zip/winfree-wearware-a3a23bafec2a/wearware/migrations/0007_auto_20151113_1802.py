# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0006_device_identifier'),
    ]

    operations = [
        migrations.AddField(
            model_name='device',
            name='timezone',
            field=models.CharField(max_length=50, default='UTC'),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='device',
            name='identifier',
            field=models.CharField(unique=True, max_length=10),
        ),
    ]
