# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('wearware', '0021_auto_20151204_1214'),
    ]

    operations = [
        migrations.RenameModel('Device', 'FitbitAccount')
    ]
