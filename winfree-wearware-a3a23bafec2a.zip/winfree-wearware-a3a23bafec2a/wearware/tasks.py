from __future__ import absolute_import

from celery import shared_task

from .fitbit import *
from .models import *


@shared_task
@transaction.atomic
def fitbit_refresh_tokens():
    """Scheduled task to refresh Fitbit authentication tokens."""
    for device in FitbitAccount.objects.select_for_update().filter(is_active=True):
        fitbit_refresh_access_token(device)


@shared_task
@transaction.atomic
def fitbit_update_activity_data(owner_id):
    """Fetch up to date activity data for a given Fitbit account."""
    try:
        # very important that this select_for_update happens in a @transaction.atomic
        # to prevent multiple notifications running in sync and clobbering a user's records
        device = FitbitAccount.objects.select_for_update().get(identifier=owner_id)

        if not device.is_active:
            log.warning('Asked to update data for device %s, but it\'s marked as inactive. Skipping.', owner_id)
            return

        # save the notification before we do anything else
        notification_record = SyncRecord(device=FitbitAccount.objects.get(identifier=owner_id),
                                         start_time=timezone.now(),
                                         end_time=timezone.now(),
                                         sync_type='fitbit-notification',
                                         successful=True,
                                         message='Received valid fitbit notification '
                                                 'for device {}'.format(owner_id))
        notification_record.save()

    except FitbitAccount.DoesNotExist:
        log.warning('Asked to update data for device %s, but it\' doesn\'t exist! Skipping.', owner_id)
        return

    # start figuring out how far back our updates need to go
    subject_tz = pytz_tz(device.timezone)
    now_in_subject_tz = timezone.now().astimezone(subject_tz)  # - datetime.timedelta(minutes=5)
    last_updated = device.last_updated.astimezone(subject_tz)

    # find the previous successful sync and update the heartrate data
    try:
        previous_hr_sync_time = SyncRecord.objects.filter(
            successful=True, device=device, sync_type='fitbit-steps') \
            .order_by('-start_time')[1].timestamp.astimezone(subject_tz)

        previous_hr_sync_time -= datetime.timedelta(minutes=5)

        log.info('Attempting to backfill fitbit heartrate data for %s from %s to %s.', device.identifier,
                 previous_hr_sync_time, last_updated)
        fitbit_fetch_fresh_data(device, previous_hr_sync_time, last_updated, ['heart'])
    except IndexError:
        pass

    if last_updated >= now_in_subject_tz:
        return

    # try to get the rest of the data
    last_good_fetch = fitbit_fetch_fresh_data(device, last_updated, now_in_subject_tz,
                                              ['calories', 'steps', 'distance', 'heart'])

    if last_good_fetch is not None:
        device.last_updated = last_good_fetch - datetime.timedelta(minutes=3)
        device.save()


@shared_task
def activate_current_studies():
    """Check for and activate pending studies which need to be started."""
    for study in Study.objects.filter(start_date=datetime.datetime.today()):
        log.info('Activating study %s.', study.identifier)
        for subject in Subject.objects.filter(study=study):
            for device in FitbitAccount.objects.filter(subject=subject):
                fitbit_start_subscription(device.pk)
                device.is_active = True
                device.save()


@shared_task
def deactivate_expired_studies():
    """Check for and deactivate active studies which should be over."""
    for study in Study.objects.filter(end_date__lte=datetime.datetime.today()):
        log.info('Deactivating study %s.', study.identifier)
        for subject in Subject.objects.filter(study=study):
            for device in FitbitAccount.objects.filter(subject=subject):
                fitbit_end_subscription(device.pk)

                device.is_active = False
                device.identifier = ''
                device.token_type = None
                device.access_token = None
                device.refresh_token = None
                device.save()
