"""
Define custom admin interface views.

Any models without a custom view defined will have the defaults created.
"""

from django.contrib import admin
from .models import *


class SubjectInlineViewAdmin(admin.TabularInline):
    model = Subject
    extra = 0
    readonly_fields = ('identifier', 'email', 'sex', 'gender', 'comments')

    def has_delete_permission(self, request, obj=None):
        return False

    def has_add_permission(self, request):
        return False


class SubjectInlineCreateAdmin(admin.TabularInline):
    model = Subject
    extra = 0

    def has_change_permission(self, request, obj=None):
        return False


class StudyEditAdmin(admin.ModelAdmin):
    inlines = [
        SubjectInlineViewAdmin,
        SubjectInlineCreateAdmin,
    ]

    def get_readonly_fields(self, request, obj=None):
        if obj:
            return ['identifier', 'start_date', 'end_date', 'comment']
        return []

    def has_delete_permission(self, request, obj=None):
        return False


admin.site.register(Study, StudyEditAdmin)
