import base64
import datetime
import json
import logging
from urllib.parse import urlsplit, urlencode, urlunsplit

import requests
from django.conf import settings
from django.core.mail import mail_managers, send_mail
from django.db import transaction
from django.template import loader, Context
from django.utils import timezone
from pytz import timezone as pytz_tz

from .models import FitbitAccount, SyncRecord, FitbitMinuteRecord, FitbitHeartRecord

fitbit_auth_url = 'https://www.fitbit.com/oauth2/authorize'
fitbit_token_url = 'https://api.fitbit.com/oauth2/token'

log = logging.getLogger(__name__)


def fitbit_build_auth_url(subject):
    """Construct an authentication URL for a given subject."""
    params = {
        'client_id': settings.FITBIT_CLIENT_ID,
        'response_type': 'code',
        'scope': 'activity heartrate location sleep profile',
        'state': str(subject.pk) + ' ' + subject.pairing_token.hex,
    }
    url_parts = list(urlsplit(fitbit_auth_url))
    url_parts[3] = urlencode(params)
    auth_url = urlunsplit(url_parts)
    return auth_url


def fitbit_build_request_headers(device=None):
    """Construct shared request headers for fitbit requests."""

    # authenticate using application secret if there's no device
    if device is None:
        fitbit_auth_blob = settings.FITBIT_CLIENT_ID + ':' + settings.FITBIT_CLIENT_SECRET
        fitbit_auth_blob = fitbit_auth_blob.encode('utf8')
        auth_header = 'Basic ' + base64.b64encode(fitbit_auth_blob).decode('utf8')

    else:
        # otherwise authenticate using device-specific token
        auth_header = device.token_type + ' ' + device.access_token

    headers = {
        'Authorization': auth_header,
        'Accept-Locale': 'en_US',
        'Accept-Language': 'en_US',
    }
    return headers


def fitbit_fetch_permanent_token(temp_token):
    """Use a temporary auth token to retrieve a reusable auth token from Fitbit."""
    headers = fitbit_build_request_headers()

    payload = {
        'code': temp_token,
        'grant_type': 'authorization_code',
        'client_id': settings.FITBIT_CLIENT_ID
    }

    r = requests.post(fitbit_token_url, data=payload, headers=headers)
    if not r.ok:
        log.error('Unable to fetch permanent token (%s): %s', r.status_code, r.text)
        r.raise_for_status()

    auth_info = json.loads(r.text)
    return auth_info


reauthorization_template = loader.get_template('fitbit/fitbit_reauthorize_email.txt')


def fitbit_refresh_access_token(device):
    """Refresh an account's access token."""
    headers = fitbit_build_request_headers()

    payload = {
        'grant_type': 'refresh_token',
        'refresh_token': device.refresh_token,
    }

    log.info('Requesting fresh auth token for device_id %s.', device.pk)
    r = requests.post(fitbit_token_url, data=payload, headers=headers)

    # the happy path here is pretty brief, but we need to attempt to notify an admin if this fails
    if not r.ok:
        log.error('Unable to refresh auth token for device %s:\n%s', device.pk, r.text)

        error_info = json.loads(r.text)
        invalid_token = 'invalid_grant' in [e['errorType'] for e in error_info['errors']]

        if invalid_token:
            failed_refresh = SyncRecord(device=device,
                                        start_time=timezone.now(),
                                        end_time=timezone.now(),
                                        sync_type='fitbit-token-refresh',
                                        successful=False,
                                        message='Failed refreshing token for device. '
                                                'Request:{}\n{}\n{}\n'
                                                'Response:\n{}\n{}'.format(
                                                fitbit_token_url, headers, payload,
                                                r.headers, r.text))
            failed_refresh.save()

            # TODO dynamically insert server address FIXME
            context = Context(
                    {'device': device, 'pairing_token': device.subject.pairing_token})
            email_body = reauthorization_template.render(context)

            try:
                send_mail('WearWare - Reauthorization Needed', email_body, settings.DEFAULT_FROM_EMAIL,
                          [device.subject.email])

                email_body = """{}\'s auth refresh failed. Email sent to their registered address.
                Request:
                {} {}\n{}\n{}
                Response:
                {} {}:{}\n{}\n{}\n{}
                Fitbit account:
                {}, {}, {}, {}, {}, {}
                """.format(
                        device.subject.identifier,
                        r.request.method, r.request.url, r.request.headers, r.request.body,
                        r.elapsed, r.status_code, r.url, r.headers, r.text, r.cookies,
                        device.identifier, device.subject.identifier, device.last_updated, device.token_type,
                        device.refresh_token,
                        device.access_token)
                mail_managers('WearWare - Subject auth refresh failed', email_body, fail_silently=True)

                log.warning(
                        'Sent email requesting reauthorization to %s for fibit account %s.',
                        device.subject.email,
                        device.identifier)
            except:
                log.error('Unable to send email to %s for fitbit reauthorization.', device.subject.email)

            log.error('Disabling device %s due to invalid refresh token.', device.identifier)
            device.is_active = False
            device.save()
        return

    # if we get this far, the request succeeded and we did not email an admin
    auth_info = json.loads(r.text)

    # FIXME now that we don't store raw json, these should be removeable, but needs testing
    auth_info.pop('scope')
    auth_info.pop('expires_in')

    device.token_type = auth_info['token_type']
    device.access_token = auth_info['access_token']
    device.refresh_token = auth_info['refresh_token']
    device.is_active = True
    device.save()

    refresh_sync = SyncRecord(device=device,
                              start_time=timezone.now(),
                              end_time=timezone.now(),
                              sync_type='fitbit-token-refresh',
                              successful=True,
                              message='Succeeded refreshing token for device.')
    refresh_sync.save()

    log.info('Successfully updated authentication info for fitbit %s.', device.identifier)


def fitbit_start_subscription(device_id):
    """Start an account subscription for wearware, so we'll be notified on syncs."""
    device = FitbitAccount.objects.get(pk=device_id)
    headers = fitbit_build_request_headers(device)

    # FIXME this has got to be vulnerable to some sort of injection
    requests.post('https://api.fitbit.com/1/user/-/activities/apiSubscriptions/{}.json'.format(device.subject.pk),
                  headers=headers)

    log.info('Registered fitbit subscription for device %s.', device_id)


def fitbit_end_subscription(device_id):
    device = FitbitAccount.objects.get(pk=device_id)
    headers = fitbit_build_request_headers(device)

    # get list of active subscriptions for user
    r = requests.get('https://api.fitbit.com/1/user/-/activities/apiSubscriptions.json', headers=headers)

    if not r.ok:
        log.error('Problem deleting subscription for fibit account %s: %s', device.identifier, r.text)
        return

    subs = json.loads(r.text).get('apiSubscriptions', [])

    # delete all active subscriptions
    for sub in subs:
        try:
            sub_id = sub['subscriptionId']
            url = 'https://api.fitbit.com/1/user/-/activities/apiSubscriptions/{}.json'.format(sub_id)
            r = requests.delete(url, headers=headers)
            r.raise_for_status()

            log.info('Deleted subscription for device %s.', device.pk)
        except KeyError:
            pass


@transaction.atomic
def fitbit_make_request(url, device_id):
    """Make a GET request to a given fitbit URL."""
    device = FitbitAccount.objects.select_for_update().get(pk=device_id)
    headers = fitbit_build_request_headers(device)

    r = requests.get(url, headers=headers)
    if not r.ok:
        log.error('Received error from response: %s, response headers:\n%s\nresponse body:\n%s',
                  r.status_code,
                  r.headers,
                  r.text)
        r.raise_for_status()
    log.info('Made GET request to %s, status %s', url, r.status_code)
    log.debug('Response:\n%s', r.text)
    return r


def fitbit_build_activity_request_url(activity_type, end_time, start_time):
    update_url = 'https://api.fitbit.com/1/user/-/activities/{activity_type}/date/' \
                 '{start_year}-{start_month}-{start_day}/1d/{resolution}/' \
                 'time/{start_hour}:{start_minute}/{end_hour}:{end_minute}.json'
    url_params = {
        'activity_type': activity_type,
        'start_year': '{:04d}'.format(start_time.year),
        'start_month': '{:02d}'.format(start_time.month),
        'start_day': '{:02d}'.format(start_time.day),
        'start_hour': '{:02d}'.format(start_time.hour),
        'start_minute': '{:02d}'.format(start_time.minute),
        'end_hour': '{:02d}'.format(end_time.hour),
        'end_minute': '{:02d}'.format(end_time.minute),
        'resolution': '1sec' if activity_type == 'heart' else '1min',
    }
    url = update_url.format(**url_params)
    return url


def fitbit_fetch_fresh_data(device, start, end, activities):
    """
    Collect fresh data for an account.

    activities is usually some subset of ['calories', 'steps', 'distance', 'heart'].
    """
    time_tuples_to_query = segment_time_range_at_midnight(start, end)
    last_good_time = None
    remaining_calls = settings.FITBIT_API_THRESHOLD
    for start_time, end_time in time_tuples_to_query:
        if remaining_calls < settings.FITBIT_API_THRESHOLD:
            log.warning(
                    'Getting close to rate limit of fitbit API calls for {}. Stopping for now.'.format(
                            device.identifier))
            break

        activity_data = {}
        for activity_type in activities:

            url = fitbit_build_activity_request_url(activity_type, end_time, start_time)
            r = fitbit_make_request(url, device_id=device.pk)

            record_sync_type = 'fitbit-{}'.format(activity_type)
            if r.ok:
                activity_data[activity_type] = r.text
                sync_record = SyncRecord(device=device, sync_type=record_sync_type,
                                         start_time=start_time, end_time=end_time,
                                         message='Fetched fitbit account {}\'s {} data from {} to {}.'.format(
                                                 device.identifier,
                                                 activity_type,
                                                 start_time,
                                                 end_time))

                last_good_time = end_time
                remaining_calls = int(r.headers['Fitbit-Rate-Limit-Remaining'])

            else:
                log.debug(r.text)
                log.error('Unable to fetch activity data for account %s!', device.identifier)

                sync_record = SyncRecord(device=device, successful=False, sync_type=record_sync_type,
                                         start_time=start_time, end_time=end_time,
                                         message='Failed fetching fitbit account {}\' {} data from {} to {}. '
                                                 'Error message: {}'.format(
                                                 device.identifier,
                                                 activities,
                                                 start_time,
                                                 end_time, r.text))

            sync_record.save()

        fitbit_parse_and_persist_activity_data(device.identifier, activity_data)
    return last_good_time


def fitbit_parse_and_persist_activity_data(owner_id, activities):
    """Take data from Fitbit's services, and convert it to our storage model, and persit it."""

    try:
        device = FitbitAccount.objects.filter(identifier=owner_id).order_by('-is_active').first()
    except FitbitAccount.DoesNotExist:
        log.warning('Asked to update data for device %s, but it\' doesn\'t exist! Skipping.', owner_id)
        return

    if not device.is_active:
        log.warning('Asked to update data for device %s, but it\'s marked as inactive. Skipping.', owner_id)
        return

    to_persist = {}

    # take the current activities-segregated data, and merge them into per-timestamp bins
    for activity in activities:
        container = json.loads(activities[activity])
        metadata_header = 'activities-{}'.format(activity)
        data_header = metadata_header + '-intraday'

        date_string = container[metadata_header][0]['dateTime']
        dataset = container[data_header]['dataset']

        for datum in dataset:
            timestamp = date_string + ' ' + datum['time']
            seconds = int(timestamp[-2:])
            timestamp = timestamp[:-2] + '00'
            if timestamp not in to_persist:
                to_persist[timestamp] = {}

            # we need process each type of data separately, but the header parsing is shared
            if activity == 'steps':
                to_persist[timestamp]['steps'] = int(datum['value'])

            elif activity == 'distance':
                to_persist[timestamp]['distance'] = float(datum['value'])

            elif activity == 'calories':
                calories = float(datum['value'])
                mets = float(datum['mets']) / 10 # kyle says div by 10 is important

                if calories == 0.0 and mets == 0.0:
                    continue

                to_persist[timestamp]['calories'] = calories
                to_persist[timestamp]['mets'] = mets
                to_persist[timestamp]['fb_level'] = int(datum['level'])

            elif activity == 'heart':
                if 'heart' not in to_persist[timestamp]:
                    to_persist[timestamp]['heart'] = []

                to_persist[timestamp]['heart'].append((seconds, datum['value']))

    # now we've binned data by timestamp, instead of by type/source
    # let's build some DB records and persist them
    for timestamp in to_persist:
        naive_dt = datetime.datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
        aware_dt = pytz_tz(device.timezone).localize(naive_dt)
        utc = pytz_tz('UTC')

        datum = to_persist[timestamp]

        # don't persist malformed items
        if 'steps' in datum and datum['steps'] == 0 and 'calories' not in datum and 'mets' not in datum:
            continue

        try:
            # let's see if we already have a record for this minute
            record = FitbitMinuteRecord.objects.get(device=device, timestamp=aware_dt.astimezone(utc))

            # if we've made it this far, there's no exception and the record exists
            # get the existing data for this minute

            # only insert new data, never overwrite existing data
            if record.steps is None:
                record.steps = datum.get('steps')

            if record.calories is None:
                record.calories = datum.get('calories')

            if record.mets is None:
                record.mets = datum.get('mets')

            if record.activity_level is None:
                record.activity_level = datum.get('fb_level')

            if record.distance is None:
                record.distance = datum.get('distance')

            if 'heart' in datum:
                hr_records = datum['heart']
                for hr_record in hr_records:
                    hr = FitbitHeartRecord(minute_record=record,
                                           second=hr_record[0],
                                           bpm=hr_record[1])
                    hr.save()

            record.save()

        except FitbitMinuteRecord.DoesNotExist:
            # just create a new record and save it
            record = FitbitMinuteRecord(device=device,
                                        timestamp=aware_dt,
                                        steps=datum.get('steps'),
                                        calories=datum.get('calories'),
                                        mets=datum.get('mets'),
                                        activity_level=datum.get('fb_level'),
                                        distance=datum.get('distance'))
            record.save()

            if 'heart' in datum:
                hr_records = datum['heart']
                for hr_record in hr_records:
                    hr = FitbitHeartRecord(minute_record=record,
                                           second=hr_record[0],
                                           bpm=hr_record[1])
                    hr.save()

        except FitbitMinuteRecord.MultipleObjectsReturned:
            # this shouldn't ever happen as long as this function is the only way used to insert fitbit data
            log.error('There are duplicate records for device %s at timestamp %s. Not updating.', device.pk, aware_dt)
            continue


def segment_time_range_at_midnight(begin, end):
    time_range_tuples = []
    segment_begin = begin
    segment_end = datetime.datetime(segment_begin.year, segment_begin.month, segment_begin.day, 23, 59, 0, 0,
                                    tzinfo=begin.tzinfo)

    while segment_begin.day != end.day:
        time_range_tuples.append((segment_begin, segment_end))
        segment_begin = segment_end + datetime.timedelta(minutes=1)
        segment_end += datetime.timedelta(days=1)

    time_range_tuples.append((segment_begin, end))
    return time_range_tuples
