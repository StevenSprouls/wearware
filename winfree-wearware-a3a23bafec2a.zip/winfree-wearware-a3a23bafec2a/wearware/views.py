"""
Non-admin views.
"""

import hmac
import pprint
import socket
import statistics

from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import Group
from django.core.exceptions import PermissionDenied
from django.db.models import Count, Q
from django.http import HttpResponseServerError, HttpResponse, HttpResponseBadRequest, Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from guardian.shortcuts import get_objects_for_user, assign_perm, remove_perm
from ipware.ip import get_real_ip

from .csv_export import *
from .fitbit import *
from .forms import *
from .models import Subject, FitbitAccount
from .tasks import fitbit_update_activity_data

log = logging.getLogger(__name__)


@login_required
def home(request):
    """Default view."""

    # show all studies to admin users, otherwise only show those studies to which the helper has
    # been assigned
    if request.user.has_perm('wearware.change_study'):
        studies = Study.objects.all().order_by('-end_date')
    else:
        # TODO sort these lists by end date after putting them together
        studies = list(get_objects_for_user(request.user, 'wearware.view_study_data').order_by('-end_date'))
        studies.extend(get_objects_for_user(request.user, 'wearware.add_subject_to_study').order_by('-end_date'))

    return render(request, 'home.html', context={'studies': studies, 'now': timezone.now().date()})


@permission_required('wearware.add_study')
def study_new(request):
    """Create a new study."""

    if request.method == 'POST':
        form = StudyCreateForm(request.POST)
        if form.is_valid():
            saved = form.save()
            log.info('Created new study: %s', saved.identifier)
            return render(request, 'study/study_add_complete.html', {'study': saved})
    else:
        form = StudyCreateForm()

    return render(request, 'study/study_add.html', {'form': form})


@permission_required('wearware.change_study')
def study_edit(request, study_id):
    """Edit a study."""

    # if the study doesn't exist, 404
    study = get_object_or_404(Study, pk=study_id)

    if request.method == 'POST':
        form = StudyEditForm(request.POST, instance=study)
        if form.is_valid():
            form.save()
            log.info('Edited study %s\'s comment for user %s.', study.identifier, request.user)
            return redirect('index')
    else:
        form = StudyEditForm(instance=study)

    return render(request, 'study/study_edit.html', {'form': form, 'study': study})


@permission_required('wearware.change_study')
def study_delete(request, study_id):
    """Delete the given study."""

    study = get_object_or_404(Study, pk=study_id)

    if request.method == 'POST':
        # we don't want to allow deleting studies with > 0 subjects
        if Subject.objects.filter(study=study).count() > 0:
            raise PermissionDenied

        study.delete()
        return render(request, 'study/study_delete_complete.html', context={'study': study})
    else:
        # we don't want to allow deleting studies with > 0 subjects
        if Subject.objects.filter(study=study).count() > 0:
            raise PermissionDenied

        return render(request, 'study/study_delete_init.html', context={'study': study})


@login_required
def subject_manage(request, study_id):
    """Render the individual subject edit/management view."""

    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.add_subject_to_study', study)):
        raise PermissionDenied

    subjects = Subject.objects.filter(study=study).order_by('identifier')
    subject_entries = []
    for subject in subjects:
        try:
            fitbit = FitbitAccount.objects.get(subject=subject)
            num_records = FitbitMinuteRecord.objects.filter(device=fitbit).count()

        except FitbitAccount.DoesNotExist:
            fitbit = None
            num_records = 0

        subject_entries.append({'subject': subject, 'fitbit': fitbit, 'num_records': num_records})

    return render(request, 'subjects/subject_manage.html', context={'study': study, 'subject_entries': subject_entries})


@login_required
def subject_enroll(request, study_id):
    """Add a new subject to a study."""

    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.add_subject_to_study', study)):
        raise PermissionDenied

    if request.method == 'POST':
        form = SubjectEnrollForm(request.POST)

        if form.is_valid():
            subject = form.save()
            return render(request, 'subjects/subject_enroll_complete.html',
                          context={'subject': subject, 'study': study})
    else:
        form = SubjectEnrollForm(initial={'study': study, 'study_start_date': study.start_date})

    return render(request, 'subjects/subject_enroll_init.html', context={'form': form, 'study': study})


@login_required
def subject_delete(request, study_id, subject_id):
    """Remove a subject from a study."""

    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.add_subject_to_study', study)):
        raise PermissionDenied

    subject = get_object_or_404(Subject, pk=subject_id)

    if request.method == 'POST':
        # don't delete any subjects who have sync records
        if FitbitMinuteRecord.objects.filter(device__subject__pk=subject.pk).count() > 0:
            raise PermissionDenied

        # if we're going to delete a subject, try deleting their notification subscription
        try:
            fitbit = FitbitAccount.objects.get(subject=subject)
            fitbit_end_subscription(fitbit.pk)
        except FitbitAccount.DoesNotExist:
            # FIXME log this
            pass

        subject.delete()
        return render(request, 'subjects/subject_delete_complete.html',
                      context={'subject': subject, 'study': study})
    else:
        # don't delete any subjects who have sync records
        if FitbitMinuteRecord.objects.filter(device__subject__pk=subject.pk).count() > 0:
            raise PermissionDenied

        return render(request, 'subjects/subject_delete_confirm.html', context={'subject': subject, 'study': study})


@login_required
def event_manage(request, study_id, subject_id):
    """Manage manually entered events for a subject."""

    study = get_object_or_404(Study, pk=study_id)

    # FIXME make this a function annotation somehow
    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.add_subject_to_study', study)):
        raise PermissionDenied

    subject = get_object_or_404(Subject, pk=subject_id)
    events = ManualEvent.objects.filter(subject=subject).order_by('-timestamp')

    return render(request, 'events/event_manage.html', context={'subject': subject, 'study': study, 'events': events})


@login_required
def event_create(request, study_id, subject_id):
    """Create a new manual event for a subject."""
    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.add_subject_to_study', study)):
        raise PermissionDenied

    subject = get_object_or_404(Subject, pk=subject_id)

    if request.method == 'POST':
        form = ManualEventForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect('study-subject-event-manage', study_id=study.pk, subject_id=subject.pk)
    else:
        form = ManualEventForm(initial={'study': study, 'subject': subject})

    return render(request, 'events/event_create_init.html',
                  context={'study': study, 'subject': subject, 'form': form})


@login_required
def event_edit(request, study_id, subject_id, event_id):
    """Edit a manually entered event."""

    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.add_subject_to_study', study)):
        raise PermissionDenied

    subject = get_object_or_404(Subject, pk=subject_id)
    event = get_object_or_404(ManualEvent, pk=event_id)

    if request.method == 'POST':
        form = ManualEventForm(request.POST, instance=event)

        if form.is_valid():
            form.save()
            return redirect('study-subject-event-manage', study_id=study.pk, subject_id=subject.pk)
    else:
        form = ManualEventForm(instance=event)

    return render(request, 'events/event_edit_init.html', context={'study': study, 'subject': subject, 'form': form})


@login_required
def event_delete(request, study_id, subject_id, event_id):
    """Delete a manually entered event."""
    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.add_subject_to_study', study)):
        raise PermissionDenied

    subject = get_object_or_404(Subject, pk=subject_id)
    event = get_object_or_404(ManualEvent, pk=event_id)

    if request.method == 'POST':
        event.delete()
        return redirect('study-subject-event-manage', study_id=study.pk, subject_id=subject.pk)
    else:
        return render(request, 'events/event_delete_init.html',
                      context={'study': study, 'subject': subject, 'event': event})


@permission_required('wearware.change_study')
def helper_summary(request):
    """Display a list of all helpers for a study."""
    group = Group.objects.get(name='Helpers')
    helpers = group.user_set.all().order_by('first_name')

    helper_dict = {}

    for helper in helpers:
        can_view = get_objects_for_user(helper, 'wearware.view_study_data')
        can_enroll = get_objects_for_user(helper, 'wearware.add_subject_to_study')
        helper_dict[helper.username] = {'user': helper, 'can_view': can_view, 'can_enroll': can_enroll}

    return render(request, 'helpers/helper_summary.html', context={'helpers': helper_dict})


@permission_required('wearware.change_study')
def helper_create(request):
    """Create a new helper account."""

    if request.method == 'POST':
        form = HelperCreateForm(request.POST)
        if form.is_valid():
            # create the helper
            group = Group.objects.get(name='Helpers')
            helper = form.save()
            group.user_set.add(helper)

            # send them a signup email
            helper_email_template = loader.get_template('helpers/helper_creation_email.txt')
            email_body = helper_email_template.render(context={'helper': helper,
                                                               'password': form.cleaned_data['password'],
                                                               'base_url': request.site.domain})
            send_mail('Helper Account Created', email_body, settings.DEFAULT_FROM_EMAIL, [helper.email],
                      fail_silently=True)

            log.info('Created new helper account: %s', helper.username)

            return render(request, 'helpers/helper_create_complete.html', context={'helper': helper})

    else:
        form = HelperCreateForm(initial={'password': uuid.uuid4().hex[0:10]})

    return render(request, 'helpers/helper_create_init.html', context={'form': form})


@permission_required('wearware.change_study')
def helper_delete(request, username):
    """Delete a helper account."""

    helper = get_object_or_404(User, username=username)

    if request.method == 'POST':
        helper.delete()
        log.info('Deleted helper account %s', helper.username)
        return render(request, 'helpers/helper_delete_complete.html', context={'username': username})

    else:
        return render(request, 'helpers/helper_delete_init.html', context={'helper': helper})


@permission_required('wearware.change_study')
def helper_grant_permission(request, username, permission):
    """Grant a helper account permission to change a study."""

    if permission not in ('view', 'enroll'):
        raise Http404('Invalid permission type.')

    helper = get_object_or_404(User, username=username)

    # FIXME this should raise an error when an invalid permission is requested
    object_perm = 'wearware.add_subject_to_study' if permission == 'enroll' else 'wearware.view_study_data'
    granted_study_pks = get_objects_for_user(helper, object_perm).values('pk')
    granted_study_pks = [s['pk'] for s in granted_study_pks]

    ungranted_studies = Study.objects.exclude(pk__in=granted_study_pks).order_by('identifier')

    if permission == 'enroll':
        ungranted_studies = ungranted_studies.exclude(end_date__lt=datetime.date.today())

    # if they already have access to all studies, fuggedaboutit
    if len(ungranted_studies) == 0:
        return render(request, 'helpers/helper_add_permission_none.html',
                      context={'helper': helper, 'permission': permission})

    # there are remaining studies for them to get permission to
    if request.method == 'POST':
        form = HelperPermissionGrantForm(request.POST, studies=ungranted_studies)

        if form.is_valid():
            study_to_grant = form.cleaned_data['study_to_grant']

            assign_perm(object_perm, helper, study_to_grant)
            log.info('Granted %s permission for study "%s" from user %s (requested by %s).',
                     object_perm,
                     study_to_grant.identifier,
                     helper.username,
                     request.user.username)

            return render(request, 'helpers/helper_add_permission_complete.html',
                          context={'helper': helper, 'permission': permission, 'study': study_to_grant})
    else:
        form = HelperPermissionGrantForm(studies=ungranted_studies)

    return render(request, 'helpers/helper_add_permission_init.html',
                  context={'helper': helper, 'permission': permission, 'form': form})


@permission_required('wearware.change_study')
def helper_revoke_permission(request, username, study_id, permission):
    """Revoke a helper's permission to a particular study."""

    helper = get_object_or_404(User, username=username)
    study = get_object_or_404(Study, pk=study_id)

    object_perm = 'wearware.add_subject_to_study' if permission == 'enroll' else 'wearware.view_study_data'

    # FIXME this should be badrequest or something like that
    if not helper.has_perm(object_perm, study):
        raise PermissionDenied

    if request.method == 'POST':
        remove_perm(object_perm, helper, study)

        log.info('Revoked %s permission for study "%s" from user %s (requested by %s).',
                 object_perm,
                 study.identifier,
                 helper.username,
                 request.user.username)

        return render(request, 'helpers/helper_revoke_permission_complete.html',
                      context={'helper': helper, 'study': study, 'permission': permission})

    else:
        return render(request, 'helpers/helper_revoke_permission_init.html',
                      context={'helper': helper, 'study': study, 'permission': permission})


@login_required
def export_study_data_as_zip(request, study_id):
    """Export a study's data as zipped CSVs."""

    study = Study.objects.get(pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.view_study_data', study)):
        raise PermissionDenied

    if datetime.date.today() < study.start_date:
        return HttpResponse('Study hasn\'t started yet!')  # TODO return proper template

    subjects = Subject.objects.filter(study=study)
    if subjects.count() == 0:
        return HttpResponse('No subjects enrolled in study yet!')  # TODO return proper template error

    num_records = 0
    for subject in subjects:
        try:
            fitbit = FitbitAccount.objects.get(subject=subject)
            num_records += FitbitMinuteRecord.objects.filter(device=fitbit).count()

            # all we care about is if the number of records is non zero
            if num_records > 0:
                break

        except FitbitAccount.DoesNotExist:
            continue

    if num_records == 0:
        return HttpResponse('No fitbit data recorded yet!')  # TODO return proper template error

    filename, export = create_zip_export_bytes(study)

    response = HttpResponse(export.getvalue(), content_type='application/zip')
    response['Content-Disposition'] = 'attachment; filename={filename}'.format(filename=filename)
    response['Content-Length'] = export.tell()
    return response


@permission_required('wearware.change_study')
def study_sync_history(request, study_id):
    """Display a history of subject sync records."""
    study = get_object_or_404(Study, pk=study_id)
    syncs = SyncRecord.objects.filter(device__subject__study__id=study.pk).order_by('-timestamp')
    return render(request, 'study/study_sync_history.html', context={'syncs': syncs[:500]})


@login_required
def study_summary(request, study_id):
    """Display a summary of patients, syncs, and activity in a study."""

    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.change_study') or
                request.user.has_perm('wearware.view_study_data', study)):
        raise PermissionDenied

    subjects = []
    # build a summary table for each subject
    for subject in Subject.objects.filter(study=study).order_by('identifier'):
        sync_records = SyncRecord.objects.filter(device__subject__pk=subject.pk,
                                                 sync_type='fitbit-notification'
                                                 ).order_by('timestamp')

        synced_yet = False
        last_sync_time = None
        sync_interval_mean = None
        sync_interval_std_dev = None

        num_syncs = len(sync_records)

        # these are valid measures as long as there's at least one sync
        if num_syncs > 0:
            synced_yet = True
            last_sync_time = sync_records.last().timestamp

        # these are only valid measures if there are at least 2 syncs
        if num_syncs > 1:
            intervals = []

            # measure sync interval for their fitbit
            prev = None
            for record in sync_records:
                if prev is not None:
                    intervals.append((record.timestamp - prev.timestamp).total_seconds() / 3600.0)

                prev = record

            sync_interval_mean = statistics.mean(intervals)
            sync_interval_std_dev = statistics.pstdev(intervals)

        subject_sync_metadata = {
            'synced_yet': synced_yet,
            'last_sync_time': last_sync_time,
            'interval_mean': sync_interval_mean,
            'interval_stddev': sync_interval_std_dev,
            'num_syncs': num_syncs,
        }

        subjects.append({'subject': subject, 'sync_metadata': subject_sync_metadata})

    return render(request, 'study/study_summary.html',
                  context={'study': study, 'subject_metadata': subjects})


@login_required
def study_summary_json(request, study_id):
    """Return a JSON encoding of subject activity levels and sync rates for a study."""
    study = get_object_or_404(Study, pk=study_id)

    if not (request.user.has_perm('wearware.view_study_data', study) or
                request.user.has_perm('wearware.change_study')):
        raise PermissionDenied

    # parse the datestring from the request parameters
    try:
        start_date = request.GET['start']
        end_date = request.GET['end']

        start = datetime.datetime.strptime(start_date, '%Y%m%d')
        end = datetime.datetime.strptime(end_date, '%Y%m%d') + datetime.timedelta(hours=23) + datetime.timedelta(
            minutes=59)

        # convert it to the timezone stored in the db
        tz = pytz_tz(settings.TIME_ZONE)

        start = tz.localize(start)
        end = tz.localize(end)

        # if we are asking for the current date, include partial day valuess for today
        if end.date() == datetime.datetime.today().date():
            end = timezone.now()

    except ValueError as e:
        return HttpResponseBadRequest('Invalid date string used! {}'.format(e))

    levels = {}

    for subject in Subject.objects.filter(study=study):
        # find the subject's fitbit account, and exclude them from the summary if they lack one
        try:
            subject_fitbit = FitbitAccount.objects.get(subject=subject)
        except FitbitAccount.DoesNotExist:
            continue

        levels[subject.identifier] = {}
        levels[subject.identifier]['usage'] = []
        levels[subject.identifier]['activity'] = []

        last_updated = subject_fitbit.last_updated
        subject_end = end if end < last_updated else last_updated

        activity_records = FitbitMinuteRecord.objects.filter(device=subject_fitbit,
                                                             timestamp__range=(start, subject_end)).order_by(
            'timestamp')

        # save activity levels from overall fitbit data
        for record in activity_records:
            if record.activity_level is not None:
                levels[subject.identifier]['activity'].append(
                    {'time': record.timestamp.isoformat(), 'level': record.activity_level})

        # compute hourly summaries of usage levels
        current_hour = start
        next_hour = current_hour + datetime.timedelta(minutes=59) + datetime.timedelta(seconds=59)
        while next_hour < subject_end:
            usage_records = activity_records.filter(timestamp__range=(current_hour, next_hour))

            num_records = usage_records.annotate(num_hearts=Count('fitbitheartrecord')).filter(
                Q(num_hearts__gt=0) | Q(steps__gt=0) | Q(mets__gt=1)).count()

            key = next_hour.isoformat()
            levels[subject.identifier]['usage'].append({'hour_ending_at': key, 'number_of_records': num_records})

            current_hour = next_hour + datetime.timedelta(minutes=1)
            next_hour += datetime.timedelta(minutes=60)

    return HttpResponse(json.dumps(levels), content_type='application/json')


def fitbit_init_auth(request, subject_id):
    """Intiate OAuth2 workflow with Fitbit. Requires pairing token from original user email."""

    subject = get_object_or_404(Subject, pk=subject_id)

    try:
        pairing_token = uuid.UUID(request.GET['token'])
    except:
        raise PermissionDenied

    if pairing_token != subject.pairing_token:
        raise PermissionDenied

    auth_url = fitbit_build_auth_url(subject)
    log.info('Initiating Fitbit pairing process for %s.', subject.identifier)
    return render(request, 'fitbit/fitbit_auth_init.html', context={'auth_url': auth_url, 'subject': subject})


def fitbit_initial_oauth_callback(request):
    """Receive authentication data from Fitbit as part of OAuth2 workflow."""

    # FIXME break this up into some logical functions

    profile_url = 'https://api.fitbit.com/1/user/-/profile.json'

    received_params = request.GET
    if 'error' in received_params:
        log.error('Fitbit passed back error (%s) in OAuth callback.', received_params['error'])
        return HttpResponseServerError('Received error from Fitbit: {}'.format(received_params['error']))

    # get back the tokens we sent to fitbit to identify which user is in question
    state = received_params['state'].split(' ')

    try:
        if len(state) != 2:  # there should be a subject ID and a pairing token, no more no less
            raise ValueError('Invalid number of state arguments received!')

        subject_id = int(state[0])

        subject = get_object_or_404(Subject, pk=subject_id)

        token = uuid.UUID(hex=state[1])
        if token != subject.pairing_token:
            raise ValueError('Invalid pairing token for subject {}!'.format(subject.identifier))

        # roll the pairing token over to a fresh random value
        subject.pairing_token = uuid.uuid4()
        subject.save()

    except ValueError as e:
        log.warning('Unable to complete OAuth pairing process (from %s): %s', get_real_ip(request), e)
        raise PermissionDenied

    # fitbit gives us a one-time-use token for getting our permanent auth info
    temp_token = received_params['code']

    # get our lasting authentication info
    auth_info = fitbit_fetch_permanent_token(temp_token)

    study_start = subject.study_start_date if subject.study_start_date > subject.study.start_date \
        else subject.study.start_date

    # FIXME unlikely to be run anywhere not AZ, but maybe worth generalizing?
    az_time = pytz_tz('America/Phoenix')
    study_start_time = timezone.datetime(study_start.year, study_start.month, study_start.day, 0, 0, 0, 0,
                                         tzinfo=az_time)

    device = FitbitAccount(subject=subject,
                           token_type=auth_info['token_type'],
                           access_token=auth_info['access_token'],
                           refresh_token=auth_info['refresh_token'],
                           last_updated=study_start_time,
                           is_active=timezone.now() >= study_start_time,
                           identifier='')
    device.save()

    log.info(
        'Successfully obtained authentication info for subject {}\'s fitbit with id {}.'.format(subject_id,
                                                                                                device.pk))

    # we now have auth info, begin the process of fetching and storing  device profile info
    headers = {
        'Authorization': (auth_info['token_type'] + ' ' + auth_info['access_token']),
        'Accept-Locale': 'en_US',
        'Accept-Language': 'en_US',
    }

    r = requests.get(profile_url, headers=headers)

    if not r.ok:
        # FIXME we probably need to cancel device creation entirely if this fails
        log.error('Received error from response: %s, response body:\n%s', r.status_code, r.text)
        return HttpResponseServerError('Unable to collect needed profile information.')

    profile = json.loads(r.text)['user']

    # throw away these fields that are useless
    # FIXME i don't think this is relevant anymore, since we don't store JSON directly
    for exclude in ('avatar', 'avatar150', 'topBadges'):
        if exclude in profile:
            profile.pop(exclude)

    device.identifier = profile['encodedId']

    # check for duplicate identifiers and delete device if it exists
    # this makes sure that spurious re-pairings don't break existing data
    try:
        # old refresh token expires as soon as new one is created, need to persist that token to the old device
        old_device = FitbitAccount.objects.get(identifier=device.identifier)
        old_device.token_type = device.token_type
        old_device.access_token = device.access_token
        old_device.refresh_token = device.refresh_token
        old_device.is_active = True
        old_device.save()

        device.delete()
        log.info('Reauthorized fitbit account %s with fresh authentication tokens.', device.identifier)

        if old_device.subject.pk != device.subject.pk:
            log.warning('Attempt to register fitbit account %s to subject %s when it\'s already paired to %s.',
                        old_device.identifier,
                        device.subject.identifier,
                        old_device.subject.identifer)

            return render(request, 'fitbit/fitbit_auth_failed.html')
        else:
            return render(request, 'fitbit/fitbit_reauth_complete.html')

    except FitbitAccount.DoesNotExist:
        # if there isn't an existing account (i.e. this wasn't spurious), create a new device entry
        # FIXME this control flow is weird, where we expect an exception to occur in happy path
        device.timezone = profile['timezone']
        device_tz = pytz_tz(device.timezone)
        device.last_updated = device.last_updated.astimezone(device_tz)
        device.save()

        if device.subject.study.start_date <= datetime.date.today():
            fitbit_start_subscription(device.pk)

        can_enroll = (request.user.has_perm('wearware.change_study') or
                      request.user.has_perm('wearware.add_subject_to_study', device.subject.study))

        return render(request, 'fitbit/fitbit_auth_complete.html', context={'can_enroll': can_enroll,
                                                                            'study': device.subject.study,
                                                                            'subject': device.subject})


@csrf_exempt
def fitbit_receive_notification(request):
    """Receive, parse, and act on a notification from Fitbit's webhook service."""

    # one security mechanism for fitbit's webhooks is a hardcoded token for our specific service
    if 'verify' in request.GET:
        if settings.FITBIT_SUBSCRIBER_VERIFICATION_CODE == request.GET['verify']:
            return HttpResponse(status=204)
        else:
            # we only want to return 204 to fitbit themseslves
            return HttpResponse(status=404)
    # FIXME we should probably cancel the notification if it's missing the verify param, need to read docs

    try:
        # two steps to validating notification before processing
        # first, confirm forward/reverse DNS lookup
        ip = get_real_ip(request)
        name = socket.gethostbyaddr(ip)[0]
        reversed_addr = socket.gethostbyname(name)
        dns_valid = reversed_addr == ip and name.endswith('fitbit.com')

        signature_valid = False
        reason = None

        if dns_valid:
            # second, verify the HMAC-SHA1 signature in the notification headers
            signature = request.META['HTTP_X_FITBIT_SIGNATURE'].encode('utf8')
            digester = hmac.new((settings.FITBIT_CLIENT_SECRET + '&').encode('utf8'), request.body,
                                digestmod='sha1')
            expected_signature = base64.b64encode(digester.digest())
            signature_valid = hmac.compare_digest(signature, expected_signature)

            if signature_valid:
                # we can have multiple notifications in a single request
                notifications = json.loads(request.body.decode('utf8'))

                devices_notified = set()
                for notification in notifications:
                    owner_id = notification['ownerId']
                    # schedule a background update of fitbit data
                    fitbit_update_activity_data.delay(owner_id)
                    devices_notified.add(owner_id)

                log.info(
                    'Received validated notification for devices %s from IP %s, sending async jobs to update data.',
                    devices_notified, ip)
            else:
                reason = 'failed to validate fitbit signature in header'
        else:
            reason = 'failed to validate forward/reverse DNS'

        if not dns_valid or not signature_valid:
            log.warning('Recieved potentially forged notification (%s)! Request META:\n%s\nRequest body:%s',
                        reason, pprint.pformat(request.META, indent=2), request.body)

    except Exception as e:
        log.error('Unable to parse or handle notification received! %s', e)

    return HttpResponse(status=204)
